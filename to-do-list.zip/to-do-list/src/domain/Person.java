package domain;

public class Person {
    private String name;
    private String familyName;
    private String id;

}
