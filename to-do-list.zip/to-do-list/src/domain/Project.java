package domain;

import java.util.ArrayList;

public class Project {
    private String projectName;
    private ArrayList<Team> teams;

}
